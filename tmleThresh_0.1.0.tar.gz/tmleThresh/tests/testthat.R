library(testthat)
library(tmleThresh)

test_check("tmleThresh")
